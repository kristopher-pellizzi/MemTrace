var searchData=
[
  ['generic_20inspection_20api',['Generic inspection API',['../group__INS__BASIC__API__GEN__IA32.html',1,'']]],
  ['generic_20modification_20api',['Generic modification API',['../group__INS__MOD__API__GEN__IA32.html',1,'']]]
];
