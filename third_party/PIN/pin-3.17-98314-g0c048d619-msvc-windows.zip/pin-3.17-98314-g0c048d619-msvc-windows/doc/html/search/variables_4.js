var searchData=
[
  ['pin_5finfinite_5ftimeout',['PIN_INFINITE_TIMEOUT',['../namespaceLEVEL__BASE.html#abdb968b58d13ad3ce88be9775b3c1564',1,'LEVEL_BASE']]],
  ['pin_5fmax_5fthreads',['PIN_MAX_THREADS',['../namespaceLEVEL__BASE.html#a420449d08905d8cee42cb0b3c6253ac7',1,'LEVEL_BASE']]]
];
