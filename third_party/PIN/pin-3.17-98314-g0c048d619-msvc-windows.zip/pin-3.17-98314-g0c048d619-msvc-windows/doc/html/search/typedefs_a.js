var searchData=
[
  ['smc_5fcallback',['SMC_CALLBACK',['../group__TRACE__BASIC__API.html#gad9941e634c7db7a8632f79fc1a6234f4',1,'LEVEL_PINCLIENT']]],
  ['syscall_5fentry_5fcallback',['SYSCALL_ENTRY_CALLBACK',['../group__PIN__SYSCALL__API.html#gad6892c860f3c69e5268de0f7f7e1ce00',1,'LEVEL_PINCLIENT']]],
  ['syscall_5fexit_5fcallback',['SYSCALL_EXIT_CALLBACK',['../group__PIN__SYSCALL__API.html#gae10e44f3b57df920d650e66b487c00df',1,'LEVEL_PINCLIENT']]]
];
