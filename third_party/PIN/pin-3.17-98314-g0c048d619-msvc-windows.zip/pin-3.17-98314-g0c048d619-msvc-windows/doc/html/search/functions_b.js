var searchData=
[
  ['numberofknobs',['NumberOfKnobs',['../group__KNOB__BASIC.html#ga847d176b0658a9c93f5dd871ec3f7909',1,'LEVEL_BASE::KNOB_BASE']]]
];
