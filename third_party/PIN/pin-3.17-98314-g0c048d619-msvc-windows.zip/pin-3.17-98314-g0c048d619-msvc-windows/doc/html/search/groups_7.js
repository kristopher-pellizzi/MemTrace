var searchData=
[
  ['img_3a_20image_20object',['IMG: Image Object',['../group__IMG__BASIC__API.html',1,'']]],
  ['ins_3a_20instruction_20object',['INS: Instruction Object',['../group__INS__BASIC__API.html',1,'']]],
  ['inspection_20api_20for_20ia_2d32_20and_20intel_28r_29_2064_20instructions',['Inspection API for IA-32 and Intel(R) 64 instructions',['../group__INS__BASIC__API__IA32.html',1,'']]],
  ['instrumentation_20api',['Instrumentation API',['../group__INS__INST__API.html',1,'']]],
  ['instrumentation_20arguments',['Instrumentation arguments',['../group__INST__ARGS.html',1,'']]],
  ['instrumentation_20for_20common_20instrumentation_20tasks',['Instrumentation for Common Instrumentation Tasks',['../group__INSTLIB.html',1,'']]]
];
