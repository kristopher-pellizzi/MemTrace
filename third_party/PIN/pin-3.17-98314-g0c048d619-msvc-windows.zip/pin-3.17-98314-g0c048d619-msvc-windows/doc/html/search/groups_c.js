var searchData=
[
  ['reg_3a_20register_20object',['REG: Register Object',['../group__REG__BASIC__API.html',1,'']]],
  ['reg_20_28generic_29',['REG (generic)',['../group__REG__CPU__GENERIC.html',1,'']]],
  ['reg_20_28specific_20to_20the_20ia_2d32_20and_20intel_28r_29_2064_20architectures_29',['REG (specific to the IA-32 and Intel(R) 64 architectures)',['../group__REG__CPU__IA32.html',1,'']]],
  ['rtn_3a_20routine_20object',['RTN: Routine Object',['../group__RTN__BASIC__API.html',1,'']]]
];
