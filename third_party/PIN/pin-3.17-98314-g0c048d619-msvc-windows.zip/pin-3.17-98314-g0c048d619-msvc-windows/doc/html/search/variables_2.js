var searchData=
[
  ['max_5fclient_5ftls_5fkeys',['MAX_CLIENT_TLS_KEYS',['../group__PIN__THREAD__API.html#gad783207300b6d463f018da9b9bebba7d',1,'LEVEL_PINCLIENT']]],
  ['max_5fwindows_5fexception_5fargs',['MAX_WINDOWS_EXCEPTION_ARGS',['../group__EXCEPTION__API.html#gaa84771de9d0e68016908593da44d9542',1,'LEVEL_BASE']]]
];
