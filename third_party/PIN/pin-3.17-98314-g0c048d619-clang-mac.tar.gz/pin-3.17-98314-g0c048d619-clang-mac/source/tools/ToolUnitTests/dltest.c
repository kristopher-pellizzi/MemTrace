/*
 * Copyright 2002-2020 Intel Corporation.
 * 
 * This software is provided to you as Sample Source Code as defined in the accompanying
 * End User License Agreement for the Intel(R) Software Development Products ("Agreement")
 * section 1.L.
 * 
 * This software and the related documents are provided as is, with no express or implied
 * warranties, other than those that are expressly stated in the License.
 */

#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <dlfcn.h>
#include <stdio.h>

#ifdef TARGET_MAC
#define ONE "libone.dylib"
#define TWO "libtwo.dylib"
#else
#define ONE "libone.so"
#define TWO "libtwo.so"
#endif

void Load(char * name, int expect)
{
    int val;
    
    void * handle;
    int (*sym)();
    
    handle = dlopen(name, RTLD_LAZY);
    if (handle == 0)
    {
        fprintf(stderr,"Load of %s failed\n",name);
        exit(1);
    }
    
    sym = (int(*)())dlsym(handle, "one");
    fprintf(stderr, "Address of sym is %p\n",sym);
    
    if (sym == 0)
    {
        fprintf(stderr,"Dlsym of %s failed\n",name);
        exit(1);
    }
    
    val = sym();
    if (val != expect)
        exit(1);
    
    dlclose(handle);
}

int main()
{
#if defined(TARGET_MAC) || defined(TARGET_BSD)
    void * mem = mmap(0, 0x2000, PROT_READ | PROT_WRITE, MAP_ANON | MAP_PRIVATE, -1, 0);
#else    
    void * mem = mmap(0, 0x2000, PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
#endif    
    fprintf(stderr, "Allocated %p\n",mem);
    // This unmap should not trigger a flush
    munmap(mem, 0x2000);
    
    Load(ONE, 1);
    Load(TWO, 2);

    return 0;
}

