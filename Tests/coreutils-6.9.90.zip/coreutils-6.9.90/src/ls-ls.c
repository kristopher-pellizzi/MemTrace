#include "ls.h"
int ls_mode = LS_LS;
