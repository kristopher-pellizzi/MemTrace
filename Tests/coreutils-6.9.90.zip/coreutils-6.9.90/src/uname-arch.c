#include "uname.h"
int uname_mode = UNAME_ARCH;
