#! /usr/bin/env bash

prefix="$(readlink -f $(dirname $0))/install"

mkdir build;
mkdir install;
./bootstrap && cd build && ../configure --prefix=$prefix && make -j 2 && make install