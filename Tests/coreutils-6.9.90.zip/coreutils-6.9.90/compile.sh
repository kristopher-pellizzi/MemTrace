#! /usr/bin/env bash

prefix="$(readlink -f $(dirname $0))/install"

mkdir build;
mkdir install;
./bootstrap && cd build && ../configure --prefix=$prefix && cp ../../patches/coreutils-6.9.90/lib/* ../lib && cp ../../patches/coreutils-6.9.90/gnulib/lib/* ../gnulib/lib && make -j 2 && make install-exec
